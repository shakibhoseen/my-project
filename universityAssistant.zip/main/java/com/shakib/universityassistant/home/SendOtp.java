package com.shakib.universityassistant.home;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class SendOtp {
    Context context;
    String phone;
   // UserModel userModel;
    OnCompleteVerification completeVerification;
    OnCodeSend codeSend;

    public interface OnCompleteVerification {
        void completed(PhoneAuthCredential phoneAuthCredential);
    }


    public void setCompleteVerification(OnCompleteVerification completeVerification) {
        this.completeVerification = completeVerification;
    }

    public interface OnCodeSend {
        void codeSend(String IndicationId);
    }

    public void setCodeSend(OnCodeSend codeSend) {
        this.codeSend = codeSend;
    }



    public SendOtp(Context context, String phone) {
        this.phone = phone;

        this.context = context;
    }


    public void sendProcess() {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phone,
                100,
                TimeUnit.SECONDS,
                (Activity) context,
                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                        if (completeVerification != null) {
                            completeVerification.completed(phoneAuthCredential);
                        }

                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {
                        Toast.makeText(context, "" + e.getMessage(), Toast.LENGTH_LONG).show();

                    }

                    @Override
                    public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {

                        if (codeSend != null) {
                            codeSend.codeSend(s);
                        }

                    }
                }
        );
    }
}
