package com.shakib.universityassistant.home;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.shakib.universityassistant.R;

public class VerificationOtpActivity extends AppCompatActivity implements TextWatcher {
    EditText input1, input2, input3, input4, input5, input6;
    TextView textShowNum;
    Button verifyBtn;
    ProgressBar progressBar;
   // UserModel userModel;
    String backendOtp;
    static boolean isSave = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification_otp);
        isSave = false;

        textShowNum = findViewById(R.id.txt_mobile_show_id);



       /* String type = getIntent().getStringExtra("context");
        if (type.equals("reg")) {
            Bundle bundle = getIntent().getExtras();
            userModel = (UserModel) bundle.getSerializable("bundle");
            callForOtp(userModel.getPhone());
            textShowNum.setText(userModel.getPhone());
        } else {
            String phone = getIntent().getStringExtra("phone"); // login activity
            callForOtp(phone);
            textShowNum.setText(phone);
        }*/
        String phone = "01798747299";
        callForOtp(phone);
        textShowNum.setText(phone);

        progressBar = findViewById(R.id.progressbar_id);
        verifyBtn = findViewById(R.id.submit_otp_id);
        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);
        input3 = findViewById(R.id.input3);
        input4 = findViewById(R.id.input4);
        input5 = findViewById(R.id.input5);
        input6 = findViewById(R.id.input6);

        input1.addTextChangedListener(this);
        input2.addTextChangedListener(this);
        input3.addTextChangedListener(this);
        input4.addTextChangedListener(this);
        input5.addTextChangedListener(this);

        //String backendOtp = getIntent().getStringExtra("backendOtp");


        verifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (input1.getText().toString().trim().isEmpty() || input2.getText().toString().trim().isEmpty() ||
                        input3.getText().toString().trim().isEmpty() || input4.getText().toString().trim().isEmpty() ||
                        input5.getText().toString().trim().isEmpty() || input6.getText().toString().trim().isEmpty()) {

                    Toast.makeText(VerificationOtpActivity.this, "please enter otp", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (backendOtp == null) {
                    Toast.makeText(VerificationOtpActivity.this, "please wait until message arrived", Toast.LENGTH_SHORT).show();
                    return;
                }
                String userOtp = input1.getText().toString() + input2.getText().toString() +
                        input3.getText().toString() + input4.getText().toString() +
                        input5.getText().toString() + input6.getText().toString();

                verifyOtp(backendOtp, userOtp);

            }
        });


    }

    private void callForOtp(String phone) {
        SendOtp sendOtp = new SendOtp(this, "+88" + phone);
        sendOtp.setCompleteVerification(new SendOtp.OnCompleteVerification() {
            @Override
            public void completed(PhoneAuthCredential phoneAuthCredential) {
                if (!isSave)
                    signIn(phoneAuthCredential);
            }
        });

        sendOtp.setCodeSend(new SendOtp.OnCodeSend() {
            @Override
            public void codeSend(String IndicationId) {
                backendOtp = IndicationId;
                Toast.makeText(VerificationOtpActivity.this, "Check your phone message", Toast.LENGTH_SHORT).show();
            }
        });

        sendOtp.sendProcess();
    }


    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        TextView text = (TextView) getCurrentFocus();

        if (text != null && text.length() > 0) {
            View next = text.focusSearch(View.FOCUS_RIGHT); // or FOCUS_FORWARD
            if (next != null)
                next.requestFocus();


        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    private void verifyOtp(String otpBakend, String otpUser) {

        PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(
                otpBakend, otpUser
        );
        if (!isSave)
            signIn(phoneAuthCredential);

    }

    private void signIn(PhoneAuthCredential phoneAuthCredential) {
        progressBar.setVisibility(View.VISIBLE);
        verifyBtn.setVisibility(View.INVISIBLE);

        isSave = true;
        FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {
                   // String id = FirebaseAuth.getInstance().getUid();
                    Toast.makeText(VerificationOtpActivity.this, "Success verified", Toast.LENGTH_SHORT).show();
                    /*if (id != null && userModel != null) {

                     //   imageUpload(Uri.parse(userModel.getUri()), id);
                    } else {
                        Toast.makeText(VerificationOtpActivity.this, "Success verified", Toast.LENGTH_SHORT).show();
                       *//* Intent intent = new Intent(VerificationOtpActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();*//*
                    }*/

                } else {
                    progressBar.setVisibility(View.GONE);
                    verifyBtn.setVisibility(View.VISIBLE);
                    Toast.makeText(VerificationOtpActivity.this, "" + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }

            }
        });

    }


    /*private void saveDetails(String profileUrl, String id) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("User").child(id);
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("name", userModel.getName());
        hashMap.put("age", userModel.getAge());
        hashMap.put("bloodgroup", userModel.getBloodGroup());
        hashMap.put("district", userModel.getDistrict());
        hashMap.put("division", userModel.getDivision());
        hashMap.put("upaZila", userModel.getUpaZila());
        hashMap.put("date", userModel.getDate());
        hashMap.put("phone", userModel.getPhone());
        hashMap.put("profileImg", profileUrl);
        reference.updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {

                    Intent intent = new Intent(VerificationOtpActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(VerificationOtpActivity.this, "Failed to save details please try again", Toast.LENGTH_SHORT).show();
                }
                progressBar.setVisibility(View.GONE);
                verifyBtn.setVisibility(View.VISIBLE);
            }
        });

    }*/

   /* private void imageUpload(Uri uri, final String id) {

        final ProgressDialog pd = new ProgressDialog(VerificationOtpActivity.this);
        pd.setMessage("uploading image..");

        pd.show();
        if (uri != null) {
            final StorageReference fileReference = FirebaseStorage.getInstance().getReference().child("user").child("profile").child(userModel.getPhone());
            fileReference.putFile(uri).
                    continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                        @Override
                        public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                            if (!task.isSuccessful()) {
                                throw task.getException();
                            }
                            return fileReference.getDownloadUrl();
                        }
                    }).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(VerificationOtpActivity.this, "upload image successful", Toast.LENGTH_SHORT).show();
                        Uri downloadUri = (Uri) task.getResult();
                        String mUri = downloadUri.toString();

                        saveDetails(mUri, id);

                    } else {
                        Toast.makeText(VerificationOtpActivity.this, "failed to success", Toast.LENGTH_SHORT).show();
                    }
                    pd.dismiss();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(VerificationOtpActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    pd.dismiss();
                }
            });
        }

    }*/
}