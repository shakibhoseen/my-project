package com.shakib.universityassistant.classroom.account.teacher.ui.studentlist;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.shakib.universityassistant.R;
import com.shakib.universityassistant.classroom.account.student.StudentDetailsActivity;
import com.shakib.universityassistant.classroom.account.StudentModel;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class StudentAllListAdapter extends RecyclerView.Adapter<StudentAllListAdapter.ViewHolder>  {

    private Context context;
    private List<StudentModel> models;




    public StudentAllListAdapter(Context context, List<StudentModel> models) {
        this.context = context;
        this.models = models;


    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new StudentAllListAdapter.ViewHolder( LayoutInflater.from(context).inflate(R.layout.all_student_list_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        final StudentModel model = models.get(position);



        //this is another way to set information to get advantage searchview
        holder.username.setText(model.getUsername());
        holder.roll.setText(model.getRoll());
        holder.email.setText(model.getEmail());
        if (model.getImageUrl()!=null) {
            if (!model.getImageUrl().equals("") && !model.getImageUrl().equals("default"))
                Glide.with(context).load(model.getImageUrl()).into(holder.profileImg);
            else holder.profileImg.setImageResource(R.drawable.meena);
        }
        else holder.profileImg.setImageResource(R.drawable.meena);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, StudentDetailsActivity.class);
                intent.putExtra("userId", model.getId());
                context.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return models.size();
    }




    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView username, email, roll;

        public CircleImageView profileImg;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.username);
            email = itemView.findViewById(R.id.filename);
            roll = itemView.findViewById(R.id.rollnoId);
            profileImg = itemView.findViewById(R.id.profile_image);

        }
    }





}
