package com.shakib.universityassistant.classroom.studentwork.slide;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.shakib.universityassistant.R;

public class SlideModificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slide_modification);
    }
}
