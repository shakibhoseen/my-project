package com.shakib.universityassistant.classroom.studentwork.assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.shakib.universityassistant.R;

public class DownloadActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download);
    }
}
