package com.shakib.universityassistant.busshedule;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.shakib.universityassistant.R;

import java.util.Date;
import java.util.List;

public class BusAdapter extends RecyclerView.Adapter<BusAdapter.ViewHolder> {

    private Context context;
    private List<BusModel> models;

    public BusAdapter(Context context, List<BusModel> models) {
        this.context = context;
        this.models = models;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.shedule_item_bus, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BusModel busModel = models.get(position);
        Date date = new Date();
        int hourNow  = date.getHours();
        int minuteNow = date.getMinutes();
        int totalNowMinute = hourNow*60 + minuteNow;

        int p_hour = Integer.parseInt(busModel.getHour());
        int p_minute = Integer.parseInt(busModel.getMinute());
        int total_p_minute =p_hour*60 + p_minute;

        if(totalNowMinute < total_p_minute ){

            int result = total_p_minute - totalNowMinute;
            if (result>=60){
                int m = result % 60;
                int h= result / 60;
                holder.hourText.setText(h+" H");
                holder.minuteText.setText(m+" minutes");

            }else{
                holder.hourText.setText(""+result);
                holder.minuteText.setText("minutes");
            }

        }
        if(p_hour>12){
            p_hour-=12;
            holder.startBusTime.setText(p_hour+":"+p_minute+" PM");
        }else{
            holder.startBusTime.setText(p_hour+":"+p_minute+" AM");
        }

        holder.pickOutPoint.setText(busModel.getPickOutPoint());
        holder.picUpPoint.setText(busModel.getPickUpPoint());
        holder.busType.setText(busModel.getBusType());




    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView hourText, minuteText, startBusTime, busType, picUpPoint, pickOutPoint;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            hourText = itemView.findViewById(R.id.hour_represent_id);
            minuteText = itemView.findViewById(R.id.minute_represent_id);
            startBusTime = itemView.findViewById(R.id.start_bus_time_id);
            busType = itemView.findViewById(R.id.type_bus_id);
            picUpPoint = itemView.findViewById(R.id.pic_up_bus_id);
            pickOutPoint = itemView.findViewById(R.id.pick_out_bus_id);
        }
    }
}
