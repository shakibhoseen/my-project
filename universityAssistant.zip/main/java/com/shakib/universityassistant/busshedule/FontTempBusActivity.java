package com.shakib.universityassistant.busshedule;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.shakib.universityassistant.R;
import com.shakib.universityassistant.rideshare.ConstantData;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;

public class FontTempBusActivity extends AppCompatActivity implements FontAdapter.OnDownloadClick , StoreBusDataHelper.OnResponseFromCollector{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_font_temp_bus);

        SharedPreferences preferences = getSharedPreferences(ConstantData.SHARED_PREFS, MODE_PRIVATE);
        boolean ck = preferences.getBoolean(ConstantData.BUS_HELPER_SLIDE, false);
        if(ck){
            startActivity(new Intent(FontTempBusActivity.this, BusSheduleActivity.class));
            finish();
        }


        SliderView sliderView = findViewById(R.id.imageSlider);

        FontAdapter adapter = new FontAdapter (this);

        sliderView.setSliderAdapter(adapter);

        sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM); //set indicator animation by using IndicatorAnimationType. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
       // sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);

        sliderView.setIndicatorSelectedColor(Color.MAGENTA);
        sliderView.setIndicatorUnselectedColor(Color.GRAY);
        sliderView.setScrollTimeInSec(30); //set scroll delay in seconds :
        //sliderView.startAutoCycle();


        List<String> sliderItems = new ArrayList<>();
        sliderItems.add("0");
        sliderItems.add("1");
        sliderItems.add("2");


        adapter.renewItems(sliderItems);
        adapter.notifyDataSetChanged();

        adapter.setOnDownloadClickListener(this);



    }


    private View download, progress;


    @Override
    public void onDownloadClick(View view) {

        StoreBusDataHelper dataHelper = new StoreBusDataHelper(this);
        dataHelper.collectFromOnlineBusData();
        dataHelper.setCollectFromOnlineResponse(this);
        download =view.findViewById(R.id.download_btn_id);
        progress = view.findViewById(R.id.progressbar_id);

        if (download!=null || progress!=null){
            download.setVisibility(View.GONE);
            progress.setVisibility(View.VISIBLE);
        }

    }



    @Override
    public void onResponse() {
        Toast.makeText(this, "finished", Toast.LENGTH_SHORT).show();
        if (download!=null || progress!=null){
            download.setVisibility(View.VISIBLE);
            progress.setVisibility(View.GONE);
        }

        SharedPreferences preferences = getSharedPreferences(ConstantData.SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(ConstantData.BUS_HELPER_SLIDE, true);
        editor.apply();

    }


}