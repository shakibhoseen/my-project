package com.shakib.universityassistant.busshedule;

public class BusModel {
    private String busType, pickOutPoint, pickUpPoint, hour, minute;

    public BusModel() {
    }

    public String getBusType() {
        return busType;
    }

    public void setBusType(String busType) {
        this.busType = busType;
    }

    public String getPickOutPoint() {
        return pickOutPoint;
    }

    public void setPickOutPoint(String pickOutPoint) {
        this.pickOutPoint = pickOutPoint;
    }

    public String getPickUpPoint() {
        return pickUpPoint;
    }

    public void setPickUpPoint(String pickUpPoint) {
        this.pickUpPoint = pickUpPoint;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getMinute() {
        return minute;
    }

    public void setMinute(String minute) {
        this.minute = minute;
    }
}
