package com.shakib.universityassistant.busshedule;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shakib.universityassistant.R;
import com.shakib.universityassistant.rideshare.ConstantData;

import java.util.HashMap;

public class AddBusDataActivity extends AppCompatActivity implements View.OnClickListener {
    private TextInputLayout busTypeInLayout, addressInLayout, hourInLayout, minuteInLayout;
    private CheckBox yesCheckBox, noCheckBox;
    private Button setBtn;
    private boolean isYesChecked, isNoChecked;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bus_data);

        busTypeInLayout = findViewById(R.id.bus_input_layout_id);
        addressInLayout = findViewById(R.id.address_input_layout_id);
        hourInLayout = findViewById(R.id.hour_input_layout_id);
        minuteInLayout = findViewById(R.id.minute_input_layout_id);
        yesCheckBox = findViewById(R.id.checkbox_yes_Id);
        noCheckBox = findViewById(R.id.checkbox_no_Id);
        setBtn = findViewById(R.id.set_btn_id);
        progressBar = findViewById(R.id.progressbar_id);


        yesCheckBox.setOnClickListener(this);
        noCheckBox.setOnClickListener(this);
        setBtn.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        if (view == yesCheckBox) {
            if (yesCheckBox.isChecked()) noCheckBox.setChecked(false);
        }
        else if (view == noCheckBox) {
            if (noCheckBox.isChecked()) yesCheckBox.setChecked(false);
        }else if( view == setBtn){
            String busType = busTypeInLayout.getEditText().getText().toString();
            String address = addressInLayout.getEditText().getText().toString();
            String hour = hourInLayout.getEditText().getText().toString();
            String minute = minuteInLayout.getEditText().getText().toString();
            if (!yesCheckBox.isChecked() && !noCheckBox.isChecked() ){
                Toast.makeText(this, "please select destination", Toast.LENGTH_SHORT).show();
                return;
            }
            if (busType.isEmpty() || address.isEmpty() || hour.isEmpty() || minute.isEmpty()){
                Toast.makeText(this, "All required needed", Toast.LENGTH_SHORT).show();
                return;
            }

            if (yesCheckBox.isChecked()){
                saveDataBase(busType, address, "Campus", hour, minute);
            }else{
                saveDataBase(busType, "Campus", address, hour, minute);
            }
           
        }
    }




    private void saveDataBase( String busType, String  pickOutPoint, String pickUpPoint, String hour, String minute) {
        progressBar.setVisibility(View.VISIBLE);
        setBtn.setVisibility(View.INVISIBLE);
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference(ConstantData.BUS_SCHEDULE);

        HashMap<String, Object> hashMap = new HashMap<>();

        hashMap.put("busType", busType);
        hashMap.put("pickOutPoint", pickOutPoint);
        hashMap.put("pickUpPoint", pickUpPoint);
        hashMap.put("hour", hour);
        hashMap.put("minute", minute);

        ref.push().setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    Toast.makeText(AddBusDataActivity.this, "successfully saved", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(AddBusDataActivity.this, ""+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
                progressBar.setVisibility(View.GONE);
                setBtn.setVisibility(View.VISIBLE);
            }
        });
    }


}