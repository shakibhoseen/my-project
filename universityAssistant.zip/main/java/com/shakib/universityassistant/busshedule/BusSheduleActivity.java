package com.shakib.universityassistant.busshedule;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shakib.universityassistant.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BusSheduleActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private BusAdapter busAdapter;
    private List<BusModel> holdModels, models;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_shedule);

        holdModels = new ArrayList<>();
        models = new ArrayList<>();

       /* BusModel model = new BusModel();
        model.setHour("23");
        model.setMinute("20");
        models.add(model);
        BusModel model1 = new BusModel();
        model1.setHour("21");
        model1.setMinute("20");
        models.add(model1);*/
        busAdapter = new BusAdapter(this, models);


        recyclerView = findViewById(R.id.recyclerId);
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager =new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(busAdapter);


        readBusDataFromOffline();
    }


    private void readBusDataFromOffline(){
        holdModels.clear();
        StoreBusDataHelper dataHelper = new StoreBusDataHelper(this);

        Cursor cursor = dataHelper.getAlldata();

        while (cursor.moveToNext()){
            BusModel model = new BusModel();

            model.setBusType(cursor.getString(1));
            model.setPickOutPoint(cursor.getString(2));
            model.setPickUpPoint(cursor.getString(3));
            model.setHour(cursor.getString(4));
            model.setMinute(cursor.getString(5));

            holdModels.add(model);
        }
        validModel();
    }

    private void validModel(){
        models.clear();
        int size = holdModels.size();
        Toast.makeText(this, "hold "+size, Toast.LENGTH_SHORT).show();
        int currentHour = new Date().getHours();
        int currentMinute = new Date().getMinutes();
        for (int i=0; i<size; i++){
            BusModel model = holdModels.get(i);
            if (Integer.parseInt(model.getHour())> currentHour){
                 models.add(model);
            }else if(Integer.parseInt(model.getHour())== currentHour){
                if (Integer.parseInt(model.getMinute())>currentMinute){
                    models.add(model);
                }
            }
        }
        Toast.makeText(this, "hold "+models.size(), Toast.LENGTH_SHORT).show();
        busAdapter.notifyDataSetChanged();
    }
}