package com.shakib.universityassistant.busshedule;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.fragment.app.FragmentManager;

import com.shakib.universityassistant.R;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.ArrayList;
import java.util.List;

public class FontAdapter extends SliderViewAdapter<FontAdapter.SliderAdapterVH> {
    public OnDownloadClick onDownloadClick;
    private Context context;
    private List<String> mSliderItems = new ArrayList<>();
    FragmentManager fragmentManager;

    public FontAdapter(Context context) {
        this.context = context;
    }

    public interface OnDownloadClick {
        void onDownloadClick(View view);
    }

    public void setOnDownloadClickListener(OnDownloadClick onDownloadClick) {
        this.onDownloadClick = onDownloadClick;
    }

    public void renewItems(List<String> sliderItems) {
        this.mSliderItems = sliderItems;
        notifyDataSetChanged();
    }

    public void deleteItem(int position) {
        this.mSliderItems.remove(position);
        notifyDataSetChanged();
    }

    public void addItem(String sliderItem) {
        this.mSliderItems.add(sliderItem);
        notifyDataSetChanged();
    }


    @Override
    public SliderAdapterVH onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.font_bus_temp_slide_item, null);
        return new SliderAdapterVH(inflate);
    }

    @Override
    public void onBindViewHolder(SliderAdapterVH viewHolder, int position) {

        viewHolder.containerView.removeAllViews();

        if (position==0){
            View view = LayoutInflater.from(context).inflate(R.layout.bus_sedule_temp_child_item3, null);
            viewHolder.containerView.addView(view);

        }
       else if (position==1){
            View view = LayoutInflater.from(context).inflate(R.layout.bus_sedule_temp_child_item1, null);
            viewHolder.containerView.addView(view);

        }else if(position==2){
            View view = LayoutInflater.from(context).inflate(R.layout.bus_sedule_temp_child_item2, null);
            viewHolder.containerView.addView(view);
            View downloadBtn = view.findViewById(R.id.download_btn_id);

           downloadBtn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View p) {
                   if (onDownloadClick!=null){
                        onDownloadClick.onDownloadClick(view);

                   }

               }
           });

        }


    }

    @Override
    public int getCount() {
        return mSliderItems.size();
    }

    public class SliderAdapterVH extends SliderViewAdapter.ViewHolder {
        private FrameLayout containerView;
        private ImageView downloadBtn;

        public SliderAdapterVH(View itemView) {
            super(itemView);
            containerView = itemView.findViewById(R.id.fragment_container);



        }
    }
}
