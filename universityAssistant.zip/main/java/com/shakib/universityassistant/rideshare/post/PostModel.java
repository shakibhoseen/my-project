package com.shakib.universityassistant.rideshare.post;

public class PostModel {
    String pickOutAddress, pickUpAddress, cost, owner, postId;
    long publish, pickUpTime, pickOutTime;

    public PostModel() {
    }

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getPickOutAddress() {
        return pickOutAddress;
    }

    public void setPickOutAddress(String pickOutAddress) {
        this.pickOutAddress = pickOutAddress;
    }

    public String getPickUpAddress() {
        return pickUpAddress;
    }

    public void setPickUpAddress(String pickUpAddress) {
        this.pickUpAddress = pickUpAddress;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public long getPublish() {
        return publish;
    }

    public void setPublish(long publish) {
        this.publish = publish;
    }

    public long getPickUpTime() {
        return pickUpTime;
    }

    public void setPickUpTime(long pickUpTime) {
        this.pickUpTime = pickUpTime;
    }

    public long getPickOutTime() {
        return pickOutTime;
    }

    public void setPickOutTime(long pickOutTime) {
        this.pickOutTime = pickOutTime;
    }
}
