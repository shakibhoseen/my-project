package com.shakib.universityassistant.rideshare.post;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shakib.universityassistant.R;

import java.util.ArrayList;
import java.util.List;

public class PostFragment extends Fragment {

    private PostViewModel mViewModel;
    private List<PostModel> postModels = new ArrayList<>();
    private RecyclerView recyclerView;
    private AdapterPost adapterPost ;

    public static PostFragment newInstance() {
        return new PostFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.post_fragment, container, false);


        recyclerView = root.findViewById(R.id.recyclerId);
        recyclerView.setHasFixedSize(true);

        adapterPost = new AdapterPost(getContext(), postModels);
        
        LinearLayoutManager linearLayoutManager =new LinearLayoutManager(getContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapterPost);

        return root;

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);




        // TODO: Use the ViewModel

        mViewModel =  new ViewModelProvider(this).get(PostViewModel.class);
        mViewModel.getPostMutableLiveData().observe(getViewLifecycleOwner(), new Observer<List<PostModel>>() {
            @Override
            public void onChanged(List<PostModel> postModels1) {
                postModels.addAll(postModels1) ;
                adapterPost.notifyDataSetChanged();
                Toast.makeText(getContext(), ""+postModels1.size(), Toast.LENGTH_SHORT).show();
                Toast.makeText(getContext(), ""+postModels.size(), Toast.LENGTH_SHORT).show();
            }
        });

    }

}