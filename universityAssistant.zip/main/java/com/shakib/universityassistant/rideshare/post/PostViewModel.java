package com.shakib.universityassistant.rideshare.post;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.shakib.universityassistant.rideshare.ConstantData;

import java.util.ArrayList;
import java.util.List;

public class PostViewModel extends ViewModel {
    // TODO: Implement the ViewModel
  private MutableLiveData<List<PostModel>> postMutableLiveData;
    private List<PostModel> postModels;

    public PostViewModel() {
        postMutableLiveData = new MutableLiveData<>();
        postModels =  new ArrayList<>();

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference(ConstantData.RIDE_SHARE_DATA_BASE_NAME)
                .child(ConstantData.POST_RIDE);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                postModels.clear();
                for (DataSnapshot snapshot: dataSnapshot.getChildren()){
                    PostModel model = snapshot.getValue(PostModel.class);
                    assert model != null;
                    model.setPostId(snapshot.getKey());
                    postModels.add(model);
                }
                postMutableLiveData.setValue(postModels);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public MutableLiveData<List<PostModel>> getPostMutableLiveData() {
        return postMutableLiveData;
    }
}