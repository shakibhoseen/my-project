package com.shakib.universityassistant.rideshare.post;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.shakib.universityassistant.R;
import com.shakib.universityassistant.classroom.studentwork.quiz.DateUtils;
import com.shakib.universityassistant.rideshare.ConstantData;
import com.shakib.universityassistant.rideshare.MapActivity;

import java.util.HashMap;
import java.util.List;

public class AdapterPost extends RecyclerView.Adapter<AdapterPost.ViewHolder> {
    private Context context;
    private List<PostModel> postModels;
    private String userId = FirebaseAuth.getInstance().getUid();

    public AdapterPost(Context context, List<PostModel> postModels) {
        this.context = context;
        this.postModels = postModels;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.post_item_1, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        PostModel model = postModels.get(position);

        holder.pickOut.setText(model.getPickOutAddress());
        holder.pickUp.setText(model.getPickUpAddress());
        holder.name.setText(DateUtils.dateFromLong(model.getPublish()));
        holder.cost.setText("$" + model.getCost());
        holder.pickUpTime.setText(DateUtils.dateFromLong(model.getPickUpTime()));
    }

    @Override
    public int getItemCount() {
        return postModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView pickOut, pickUp, cost, name, pickUpTime;
        private ImageView profile;
        private Button messageBtn, requestBtn;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            pickOut = itemView.findViewById(R.id.pick_out_location_id);
            pickUp = itemView.findViewById(R.id.pick_up_location_id);
            pickUpTime = itemView.findViewById(R.id.time_pick_up_id);
            profile = itemView.findViewById(R.id.driver_profile_img_id);
            name = itemView.findViewById(R.id.driver_name_id);
            cost = itemView.findViewById(R.id.cost_id);
            messageBtn = itemView.findViewById(R.id.message_btn_id);
            requestBtn = itemView.findViewById(R.id.request_btn_id);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    context.startActivity(new Intent(context, MapActivity.class));
                }
            });

            messageBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    createMsgGroup(postModels.get(getAdapterPosition()));
                }
            });

        }
    }

    private void createMsgGroup(PostModel postModel) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(ConstantData.RIDE_SHARE_DATA_BASE_NAME)
                .child(ConstantData.POST_CHAT).child(ConstantData.POST_CHAT_HEADER).child(postModel.getPostId());
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    HashMap<String, Object> hashMap = new HashMap<>();
                    hashMap.put("owner", postModel.getOwner());
                    reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                               // Toast.makeText(context, "chat header created", Toast.LENGTH_SHORT).show();
                                DatabaseReference reference2 = FirebaseDatabase.getInstance().getReference(ConstantData.RIDE_SHARE_DATA_BASE_NAME)
                                        .child(ConstantData.POST_CHAT).child(ConstantData.POST_CHAT_CLIENT).child(postModel.getPostId());

                                HashMap<String, Object> hashMap2 = new HashMap<>();
                                hashMap2.put("id", postModel.getOwner());
                                reference2.child(postModel.getOwner()).setValue(hashMap2);

                                Toast.makeText(context, "client add successfully", Toast.LENGTH_SHORT).show();

                                if (!userId.equals(postModel.getOwner())) {
                                    addClient(postModel);
                                }


                            }
                        }
                    });
                }else{  //exists if then
                    DatabaseReference reference3 = FirebaseDatabase.getInstance().getReference(ConstantData.RIDE_SHARE_DATA_BASE_NAME)
                            .child(ConstantData.POST_CHAT).child(ConstantData.POST_CHAT_CLIENT).child(postModel.getPostId());
                    reference3.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(!snapshot.exists()){
                                addClient(postModel);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });



                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



    private void addClient(PostModel postModel){
        DatabaseReference reference2 = FirebaseDatabase.getInstance().getReference(ConstantData.RIDE_SHARE_DATA_BASE_NAME)
                .child(ConstantData.POST_CHAT).child(ConstantData.POST_CHAT_CLIENT).child(postModel.getPostId());

            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("id", userId);
            reference2.child(userId).setValue(hashMap);



    }


}
