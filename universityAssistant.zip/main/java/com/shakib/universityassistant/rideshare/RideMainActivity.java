package com.shakib.universityassistant.rideshare;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.shakib.universityassistant.R;
import com.shakib.universityassistant.rideshare.chat.ChatFragment;
import com.shakib.universityassistant.rideshare.notification.NotificationFragment;
import com.shakib.universityassistant.rideshare.post.PostFragment;

public class RideMainActivity extends AppCompatActivity {
    private TextView toolbarTxt;
    Fragment selectedFragment = null;
    boolean isPost = true, isChat = false, isNotification = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbarTxt = findViewById(R.id.toolbar_txt);


        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);


        // getSupportActionBar().setTitle(crsNm);
       // toolbarTxt.setText(crsNm);
        if (savedInstanceState == null) {
            selectedFragment = PostFragment.newInstance();
            getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, selectedFragment, "s").
                    setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                    .commit();

        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_teacher, menu);
        return super.onCreateOptionsMenu(menu);
    }


    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                    switch (menuItem.getItemId()) {
                        case R.id.nav_slide:
                            isNotification = false;
                            isChat = false;
                            isPost = true;
                            selectedFragment = PostFragment.newInstance();
                            //  getSupportActionBar().setTitle("Note");
                            break;
                        case R.id.nav_quiz:
                            isNotification = false;
                            isChat = true;
                            isPost = false;
                            selectedFragment = ChatFragment.newInstance();
                            //  getSupportActionBar().setTitle("Favorite");
                            break;
                        case R.id.nav_assign:
                            isNotification = true;
                            isChat = false;
                            isPost = false;
                            selectedFragment = NotificationFragment.newInstance();
                            //  getSupportActionBar().setTitle("Search");
                            break;
                    }

                    openFragment();

                    return true;
                }
            };


    public void openFragment() {
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                selectedFragment).commit();
    }


    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putBoolean("Agn", isNotification);
        outState.putBoolean("Qiz", isChat);
        outState.putBoolean("Sld", isPost);

    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        isNotification = savedInstanceState.getBoolean("Agn");
        isChat = savedInstanceState.getBoolean("Qiz");
        isPost = savedInstanceState.getBoolean("Sld");
        if (isNotification) {
            selectedFragment = NotificationFragment.newInstance();
        } else if (isChat) {
            selectedFragment = ChatFragment.newInstance();
        } else {
            selectedFragment = PostFragment.newInstance();
        }
        //  openFragment();
    }
}