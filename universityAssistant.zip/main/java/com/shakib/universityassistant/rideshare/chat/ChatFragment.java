package com.shakib.universityassistant.rideshare.chat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shakib.universityassistant.R;
import com.shakib.universityassistant.rideshare.chat.group.UserAdapter;

import java.util.ArrayList;
import java.util.List;

public class ChatFragment extends Fragment {

    private ChatViewModel mViewModel;
    private List<HeaderModel> models= new ArrayList<>();
    private List<HeaderModel> finalModel= new ArrayList<>();

    private RecyclerView recyclerView;
    private UserAdapter userAdapter;

    public static ChatFragment newInstance() {
        return new ChatFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root=  inflater.inflate(R.layout.chat_fragment, container, false);



        recyclerView = root.findViewById(R.id.recyclerId);
        recyclerView.setHasFixedSize(true);

        userAdapter = new UserAdapter(getContext(), finalModel);

        LinearLayoutManager linearLayoutManager =new LinearLayoutManager(getContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(userAdapter);






        return root;

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(ChatViewModel.class);



        // TODO: Use the ViewModel

        mViewModel.getGroupHeadersId().observe(getViewLifecycleOwner(), new Observer<List<HeaderModel>>() {
            @Override
            public void onChanged(List<HeaderModel> headerModels1) {
                models.clear();
                 models.addAll(headerModels1);
                processChat();
            }
        });





    }




    private void processChat(){
        finalModel.clear();

        for (int i=0; i<models.size(); i++){

            HeaderModel model = models.get(i);

            if (model.isPresent()){
                finalModel.add(model);
            }
        }
        userAdapter.notifyDataSetChanged();
        
    }


}