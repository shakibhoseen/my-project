package com.shakib.universityassistant.rideshare.chat;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.shakib.universityassistant.rideshare.ConstantData;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

public class ChatViewModel extends ViewModel {
    // TODO: Implement the ViewModel

    private MutableLiveData<List<HeaderModel>> groupHeadersId;
    private List<HeaderModel> headerSId;
    private String  userId;


    public ChatViewModel() {
        groupHeadersId = new MutableLiveData<>();
        headerSId = new ArrayList<>();
        userId = FirebaseAuth.getInstance().getUid();

        collectChatHead();

    }

    public MutableLiveData<List<HeaderModel>> getGroupHeadersId() {
        return groupHeadersId;
    }

    private void collectChatHead() {


        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(ConstantData.RIDE_SHARE_DATA_BASE_NAME)
                .child(ConstantData.POST_CHAT).child(ConstantData.POST_CHAT_HEADER);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) return;
                headerSId.clear();
                int position =0;

                for (DataSnapshot snapshot: dataSnapshot.getChildren()){
                       //PostModel model = snapshot.getValue(PostModel.class);  ///Just for owner Id purpose i use that
                       HeaderModel headerModel = new HeaderModel();
                       headerModel.setId(snapshot.getKey());
                       headerSId.add(headerModel);


                }
                int size = headerSId.size();
                for (int i = 0; i <size ; i++) {
                    checkEnvolbe(headerSId.get(position).getId(), i);

                }


                groupHeadersId.setValue(headerSId);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


    private void checkEnvolbe(String id, int position){
        Timber.d("opps");
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(ConstantData.RIDE_SHARE_DATA_BASE_NAME)
                .child(ConstantData.POST_CHAT).child(ConstantData.POST_CHAT_CLIENT).child(id);
        Timber.d("opps");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()){

                    return;
                }
                boolean isPresent = false;
                for (DataSnapshot snapshot: dataSnapshot.getChildren()){

                    if (snapshot.getKey().equals(userId)){
                        headerSId.get(position).setPresent(true);
                        groupHeadersId.setValue(headerSId);
                        break;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }











}