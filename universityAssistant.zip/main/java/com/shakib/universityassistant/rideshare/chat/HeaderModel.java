package com.shakib.universityassistant.rideshare.chat;

public class HeaderModel {
    String id;
    boolean isPresent;

    public HeaderModel() {
    }

    public HeaderModel(String id, boolean isPresent) {
        this.id = id;
        this.isPresent = isPresent;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isPresent() {
        return isPresent;
    }

    public void setPresent(boolean present) {
        isPresent = present;
    }
}
