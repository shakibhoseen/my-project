package com.shakib.universityassistant.rideshare;

public class ConstantData {

    public static final String RIDE_SHARE_DATA_BASE_NAME = "RideShare";
    public static final String CLASSROOM_DATA_BASE_NAME = "classRoom";
    public static final String POST_RIDE = "post";
    public static final String POST_CHAT = "postChat";
    public static final String POST_CHAT_CONTENT = "content";
    public static final String POST_CHAT_CLIENT = "client";
    public static final String POST_CHAT_HEADER = "header";



    public static final String BUS_SCHEDULE = "busSchedule";


    public final static String SHARED_PREFS = "sharedPrefs";
    public final static String BUS_HELPER_SLIDE = "helper_slide";



}
