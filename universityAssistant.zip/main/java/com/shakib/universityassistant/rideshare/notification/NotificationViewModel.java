package com.shakib.universityassistant.rideshare.notification;

import androidx.lifecycle.ViewModel;

public class NotificationViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}