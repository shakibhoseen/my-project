package com.shakib.universityassistant.rideshare;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shakib.universityassistant.R;
import com.shakib.universityassistant.classroom.studentwork.quiz.DateUtils;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class PostActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener{

    private static final int INITIAL_REQUEST = 20;
    private Location myLocation;
    private EditText locationEditText;
    private String TAG = "post ";
    private static final LatLngBounds LAT_LNG_BOUNDS = new LatLngBounds(
            new LatLng(-40, -168), new LatLng(71, 136));

    private PlaceAutocompleteAdapter mPlaceAutocompleteAdapter;
    private GoogleApiClient mGoogleApiClient;
    private AutoCompleteTextView mSearchText;

    private TextInputLayout pickUpLayout, pickOutLayout, timeLayout, costLayout;
    private Button postBtn;
    private DateUtils dateUtils;
    FirebaseUser firebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        locationEditText = findViewById(R.id.location_edit_text);
        mSearchText = findViewById(R.id.input_search);

        pickOutLayout = findViewById(R.id.pick_out_point_layout_id);
        pickUpLayout = findViewById(R.id.pick_up_point_layout_id);
        timeLayout = findViewById(R.id.start_time);
        costLayout = findViewById(R.id.cost_id);
        postBtn = findViewById(R.id.post_id);

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        postBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(firebaseUser==null){
                    Toast.makeText(PostActivity.this, "You must login to create post", Toast.LENGTH_SHORT).show();
                    return;
                }
                String picOutTxt = pickOutLayout.getEditText().getText().toString();
                String picUpTxt = pickUpLayout.getEditText().getText().toString();
                String timeTxt = timeLayout.getEditText().getText().toString();
                String costTxt = costLayout.getEditText().getText().toString();

                if (picOutTxt == null ||picUpTxt == null ||timeTxt == null ||costTxt == null  ){
                    Toast.makeText(PostActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
                    return;
                }

                postUpload(picUpTxt, picOutTxt, dateUtils.transform(timeTxt), costTxt);


            }
        });




    }


    private void postUpload(String pickUp,String pickOut, long time, String cost){

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(ConstantData.RIDE_SHARE_DATA_BASE_NAME).child(ConstantData.POST_RIDE);
        //final String ikey = reference.push().getKey();

        HashMap<String, Object> hashMap = new HashMap<>();
        //hashMap.put("title", "");
        hashMap.put("pickOutAddress", pickOut);
        hashMap.put("owner", firebaseUser.getUid());

        hashMap.put("pickUpAddress", pickUp);          ///prepare for access to quiz untill the qestion inserted
        hashMap.put("cost", cost);          ///invalid time for access to quiz its over

        hashMap.put("pickUpTime", time);
        hashMap.put("publish", new Date().getTime());// publish date
        reference.push().setValue(hashMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(PostActivity.this, "Post Upload successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }





    private void init(){

          /* if (!canAccessLocation() || !canAccessCoreLocation()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(INITIAL_PERMS, INITIAL_REQUEST);
            }
        } else {
            boolean networkPresent = myLocation.getLocation(PostActivity.this, PostActivity.this);
            if (!networkPresent) {
                Toast.makeText(this, "please enable your network", Toast.LENGTH_SHORT).show();
            }
        }*///89.8173     22.9660

        GeocoderHandler handler = new GeocoderHandler();

        getAddressFromLocation(89.8173, 22.9660, this, handler);

        //Places.initialize(getApplicationContext(), "AIzaSyDr5eGwMyD9q-RSNUuPl9DyWrhTqEOP0PE");
        locationEditText.setFocusable(false);

        locationEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fields = Arrays.asList(Place.Field.ADDRESS
                        , Place.Field.LAT_LNG, Place.Field.NAME);

                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY,
                        fields).build(PostActivity.this);
                startActivityForResult(intent, 100);
            }
        });



        mGoogleApiClient = new GoogleApiClient
                .Builder(this)
                .addApi(Places.GEO_DATA_API)
                .addApi(Places.PLACE_DETECTION_API)
                .enableAutoManage(this, this)
                .build();

        mPlaceAutocompleteAdapter = new PlaceAutocompleteAdapter(this, mGoogleApiClient,
                LAT_LNG_BOUNDS, null);

        mSearchText.setAdapter(mPlaceAutocompleteAdapter);

        mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if(actionId == EditorInfo.IME_ACTION_SEARCH
                        || actionId == EditorInfo.IME_ACTION_DONE
                        || keyEvent.getAction() == KeyEvent.ACTION_DOWN
                        || keyEvent.getAction() == KeyEvent.KEYCODE_ENTER){

                    //execute our method for searching
                    // geoLocate();
                }

                return false;
            }
        });

    }



   /* private void geoLocate(){
        Log.d(TAG, "geoLocate: geolocating");

        String searchString = mSearchText.getText().toString();

        Geocoder geocoder = new Geocoder(PostActivity.this);
        List<Address> list = new ArrayList<>();
        try{
            list = geocoder.getFromLocationName(searchString, 1);
        }catch (IOException e){
            Log.e(TAG, "geoLocate: IOException: " + e.getMessage() );
        }

        if(list.size() > 0){
            Address address = list.get(0);

            Log.d(TAG, "geoLocate: found a location: " + address.toString());
            //Toast.makeText(this, address.toString(), Toast.LENGTH_SHORT).show();

            moveCamera(new LatLng(address.getLatitude(), address.getLongitude()), DEFAULT_ZOOM,
                    address.getAddressLine(0));
        }
    }*/








    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode ==100 && resultCode == RESULT_OK){
            Place place = Autocomplete.getPlaceFromIntent(data);
            locationEditText.setText(place.getAddress());

        }else if(resultCode == AutocompleteActivity.RESULT_ERROR){
            Status status = Autocomplete.getStatusFromIntent(data);
            Toast.makeText(this, ""+status.getStatusMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case INITIAL_REQUEST:
                if (canAccessLocation() && canAccessCoreLocation()) {
                    Toast.makeText(this, "request call back map", Toast.LENGTH_SHORT).show();
                    // boolean networkPresent = myLocation.getLocation(getActivity(), this);
                   /* if (!networkPresent) {
                        //TODO hanle error
                    }*/
                }
                break;
        }
    }


    private boolean canAccessLocation() {
        return (hasPermission(Manifest.permission.ACCESS_FINE_LOCATION));
    }

    private boolean canAccessCoreLocation() {
        return (hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION));
    }

    private boolean hasPermission(String perm) {
        return (PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(PostActivity.this, perm));
    }


    public static void getAddressFromLocation(final double latitude, final double longitude, final Context context, final Handler handler) {
        Thread thread = new Thread() {
            @Override
            public void run() {
                Geocoder geocoder = new Geocoder(context, Locale.getDefault());
                String result = null;
                try {
                    List<Address> addressList = geocoder.getFromLocation(latitude, longitude, 1);
                    if (addressList != null && addressList.size() > 0) {
                        Address address = addressList.get(0);
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                            sb.append(address.getAddressLine(i)); //.append("\n");
                        }
                        sb.append(address.getLocality()).append("\n");
                        sb.append(address.getPostalCode()).append("\n");
                        sb.append(address.getCountryName());
                        result = sb.toString();
                    }
                } catch (IOException e) {
                    Log.e("Location Address Loader", "Unable connect to Geocoder", e);
                } finally {
                    Message message = Message.obtain();
                    message.setTarget(handler);
                    if (result != null) {
                        message.what = 1;
                        Bundle bundle = new Bundle();
                        bundle.putString("address", result);
                        message.setData(bundle);
                    } else {
                        message.what = 1;
                        Bundle bundle = new Bundle();
                        result = " Unable to get address for this location.";
                        bundle.putString("address", result);
                        message.setData(bundle);
                    }
                    message.sendToTarget();
                }
            }
        };
        thread.start();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(this, "failed"+ connectionResult.getErrorMessage(), Toast.LENGTH_SHORT).show();
    }


    private class GeocoderHandler extends Handler {
        @Override
        public void handleMessage(Message message) {
            String locationAddress;
            switch (message.what) {
                case 1:
                    Bundle bundle = message.getData();
                    locationAddress = bundle.getString("address");
                    break;
                default:
                    locationAddress = null;
            }
            Log.e("location Address=", locationAddress);
            Toast.makeText(PostActivity.this, "Location Address" + locationAddress, Toast.LENGTH_SHORT).show();
        }
    }


}